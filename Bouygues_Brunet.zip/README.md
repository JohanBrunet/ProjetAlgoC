# ProjetAlgoC
Projet d'algo de 5e semestre (Polyech' Montpellier)

Définition des fichiers headers (.h) et du fichier main.c pour une bataille navale.
